// 1. Maior entre dois números
function exercicio1(num1, num2) {
    if (num1 > num2) {
        return num1 + " é maior!";
    } else {
        return num2 + " é maior!";
    }
}

// 2. Positivo ou Negativo
function exercicio2(num) {
    if (num >= 0) {
        return "Positivo";
    } else {
        return "Negativo";
    }
}

// 3. Feminino ou Masculino
function exercicio3(sexo) {
    if (sexo === "F" || sexo === "f") {
        return "Feminino";
    } else if (sexo === "M" || sexo === "m") {
        return "Masculino";
    } else {
        return "Inválido";
    }
}

// 4. Vogal ou Consoante
function exercicio4(letra) {
    if ("aeiouAEIOU".includes(letra)) {
        return "Vogal";
    } else {
        return "Consoante";
    }
}

// 5. Média das notas e aprovação
function exercicio5(n1, n2) {
    let media = (n1 + n2) / 2;
    if (media === 10) {
        return "Aprovado com Distinção!";
    } else if (media >= 7) {
        return "Aprovado";
    } else {
        return "Reprovado";
    }
}

// 6. Maior entre 3 números
function exercicio6(a, b, c) {
    return Math.max(a, b, c);
}

// 7. Maior e menor número
function exercicio7(a, b, c) {
    return "Maior: " + Math.max(a, b, c) + " / Menor: " + Math.min(a, b, c);
}

// 8. Produto mais barato
function exercicio8(p1, p2, p3) {
    return Math.min(p1, p2, p3);
}

// 9. Decrescente
function exercicio9(a, b, c) {
    let lista = [a, b, c];
    lista.sort(function (x, y) { return y - x });
    return lista;
}

// 10. Turno
function exercicio10(turno) {
    if (turno === "M" || turno === "m") return "Bom dia";
    if (turno === "V" || turno === "v") return "Boa tarde";
    if (turno === "N" || turno === "n") return "Boa noite";
    return "Valor inválido";
}

// 11. Reajuste salarial
function exercicio11(salario) {
    let novo;
    if (salario <= 280) novo = salario * 1.2;
    else if (salario <= 700) novo = salario * 1.15;
    else if (salario <= 1500) novo = salario * 1.1;
    else novo = salario * 1.05;
    return novo;
}

// 12. Folha de pagamento simples
function exercicio12(horas, valorHora) {
    let bruto = horas * valorHora;
    return bruto;
}

// 13. Dia da semana
function exercicio13(num) {
    let dias = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
    if (num >= 1 && num <= 7) {
        return dias[num - 1];
    } else {
        return "Inválido";
    }
}

// 14. Conceito de nota
function exercicio14(n1, n2) {
    let media = (n1 + n2) / 2;
    let conceito = "";
    if (media >= 9) conceito = "A, Aprovado!";
    else if (media >= 7.5) conceito = "B, Aprovado!";
    else if (media >= 6) conceito = "C, Aprovado!";
    else if (media >= 4) conceito = 'D, Reprovado!';
    else conceito = "E, Reprovado!";
    return conceito;
}

// 15. Triângulo
function exercicio15(a, b, c) {
    if (a == 0 || b == 0 || c == 0) {
        return "Não é triângulo";
    }
    if (a == b && a == c && b == c) {
        return "Equilátero";
    }
    if (a == b || a == c || b == c) {
        return "Isósceles";
    }
    if (a != b && b != c && a != c) {
        return "Escaleno";
    }

}

// 16. Raízes equação simples
function exercicio16(a, b, c) {
    if (a == 0) return "Não é equação do 2º grau";
    let delta = b * b - 4 * a * c;
    if (delta < 0) return "Sem raiz real";
    if (delta == 0) {
        let r = -b / (2 * a);
        return [r];
    }
    let r1 = (-b + Math.sqrt(delta)) / (2 * a);
    let r2 = (-b - Math.sqrt(delta)) / (2 * a);
    return [r1, r2];
}

// 17. Ano Bissexto
function exercicio17(ano) {
    if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) return "Bissexto";
    return "Não Bissexto";
}

// 18. Data válida
function exercicio18(d, m, a) {
    let data = new Date(a, m - 1, d);
    if (data && data.getDate() == d && (data.getMonth() + 1) == m) return "Válida";
    return "Inválida";
}

// 19. Decomposição simples
function exercicio19(num) {
    let c = Math.floor(num / 100);
    let d = Math.floor((num % 100) / 10);
    let u = num % 10;
    return c + " centenas, " + d + " dezenas, " + u + " unidades";
}

// 20. Média de 3 notas
function exercicio20(n1, n2, n3) {
    let media = (n1 + n2 + n3) / 3;
    if (media >= 7) return "Aprovado";
    else return "Reprovado";
}

// 21. Saque dinheiro básico
function exercicio21(valor) {
    if (valor < 10 || valor > 600) {
        return "Valor inválido (apenas de 10 a 600 reais)";
    }

    let resultado = "";
    let notas100 = Math.floor(valor / 100);
    valor = valor % 100;

    let notas50 = Math.floor(valor / 50);
    valor = valor % 50;

    let notas10 = Math.floor(valor / 10);
    valor = valor % 10;

    let notas5 = Math.floor(valor / 5);
    valor = valor % 5;

    let notas1 = valor;

    if (notas100 > 0) {
        resultado += notas100 + " nota(s) de R$100\n";
    }
    if (notas50 > 0) {
        resultado += notas50 + " nota(s) de R$50\n";
    }
    if (notas10 > 0) {
        resultado += notas10 + " nota(s) de R$10\n";
    }
    if (notas5 > 0) {
        resultado += notas5 + " nota(s) de R$5\n";
    }
    if (notas1 > 0) {
        resultado += notas1 + " nota(s) de R$1\n";
    }
    return resultado.trim();
}

// 22. Par ou ímpar
function exercicio22(num) {
    return num % 2 == 0 ? "Par" : "Ímpar";
}

// 23. Inteiro ou decimal
function exercicio23(num) {
    return Number.isInteger(num) ? "Inteiro" : "Decimal";
}

// 24. Conta simples
function exercicio24(a, b, op) {
    if (op === '+') return a + b;
    if (op === '-') return a - b;
    if (op === '*') return a * b;
    if (op === '/') return b !== 0 ? a / b : "Erro";
    return "Operação inválida";
}

// 25. Suspeita simples
function exercicio25(respostas) {
    let sim = respostas.filter(r => r == 'Sim').length;
    if (sim == 2) return "Suspeita";
    else if (sim == 3 || sim == 4) return "Culpado";
    else if (sim == 5) return "Assasino!";
    else return "Inocente";
}

// 26. Posto combustível simples
function exercicio26(litros, tipo) {
    let preco = tipo == 'A' ? 1.9 : 2.5;
    return preco * litros;
}

// 27. Frutas simples
function exercicio27(kgMor, kgMac) {
    
    // Calcula preço morango
    let precoMorango = kgMor > 5 ? 2.20 : 2.50;
    // Calcula preço maçã
    let precoMaca = kgMac > 5 ? 1.50 : 1.80;

    let totalMorango = kgMor * precoMorango;
    let totalMaca = kgMac * precoMaca;

    let total = totalMorango + totalMaca;

    // Verifica condição do desconto
    if ((kgMor + kgMac) > 8 || total > 25) {
        total = total * 0.9; // Aplica desconto de 10%
    }

    // Retorne o valor final, com duas casas decimais
    return "Total a pagar: R$ " + total.toFixed(2);
}

// 28. Churrasco básico
function exercicio28(tipo, qtd) {
    let preco = tipo == 'file' ? 4.9 : tipo == 'alcatra' ? 5.9 : 6.9;
    return preco * qtd;
}

// 29. Aprovação crédito
function exercicio29(valor, pontos) {
    return (valor <= 10000 || pontos > 10000) ? "Aprovado" : "Negado";
}

// 30. Estoque simples
function exercicio30(estoque, venda) {
    return estoque - venda >= 0 ? estoque - venda : "Não há estoque";
}
